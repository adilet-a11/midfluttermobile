
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.greenAccent,
        appBar: AppBar(
          title: Text('ff'),
          backgroundColor: Colors.blue,
        ), // This trailing comma makes auto-formatting nicer for build methods.
        body: Column(

          children:[
            Container(
              margin: const EdgeInsets.all(10),

              width: 600,height: 140,
            decoration: BoxDecoration(
                color: Colors.blue,
              borderRadius: BorderRadius.circular(10)
           //     shape:BoxShape.circle
            ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children:const [
                      Icon(Icons.home,size:100,color: Colors.yellow,),
                      Text('Home',style:TextStyle(fontSize: 20))
                    ],
                  ),


                  Icon(Icons.save,size:100,color: Colors.black,),
                  Icon(Icons.help,size:100,color: Colors.white,),
                ],
              ),
            ),
            Container(
              color: Colors.white,
              margin: const EdgeInsets.all(10),

              width: 600,height: 200,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.all(10),
                    color: Colors.blue,
                    width: 200,height: 100,
                  ),
                  Container(
                    margin: EdgeInsets.all(10),
                    color: Colors.yellow,
                    width: 100,height: 100,
                    //decoration:const BoxDecoration(
                     // color: Colors.yellow,
                     //   shape:BoxShape.circle
                    ),

                  Container(
                    margin: EdgeInsets.all(10),
                    color: Colors.red,
                    width: 200,height: 100,
                    child:Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const[
                        Text('Data 1',style:TextStyle(fontSize: 20),),
                        Text('Data 2',style:TextStyle(fontSize: 20),),
                      ],
                    ),
                  )
                ],
              ),
            )
        ],)

    );
  }
}
